#!/system/bin/sh

DEVICE="$(getprop ro.product.vendor.device)"
VENDOR_FP="$(getprop ro.vendor.build.fingerprint)"
WIFI_JAR_SHA="$(sha256sum /apex/com.android.wifi/javalib/service-wifi.jar 2>/dev/null | awk '{print $1}')"
VISIBLE_HOSTAPD_SHA="$(sha256sum /vendor/bin/hw/hostapd 2>/dev/null | awk '{print $1}')"
STOCK_HOSTAPD_SHA="44efb5abd41517f36223d897aa432291145340b95e8606531f676c03d9803203"
TESTED_EHT_HOSTAPD_SHA="74b5e192cc8ba5eef1f9eca8eab7af189b93207e156377400ca09062ffdfe60c"

[ "$DEVICE" = "onyx" ] || abort "! Unsupported device: $DEVICE"
echo "$VENDOR_FP" | grep -q 'OS3.0.7.0.WOLMIXM' || abort "! Unsupported vendor build"
[ "$WIFI_JAR_SHA" = "5762cc5e14e867639d3ac47928e1a4af509b4fe2cfc9f3c46447ec6cdf823a19" ] || abort "! service-wifi.jar does not match tested crDroid 17 build"
case "$VISIBLE_HOSTAPD_SHA" in
  "$STOCK_HOSTAPD_SHA"|"$TESTED_EHT_HOSTAPD_SHA") ;;
  *) abort "! hostapd does not match stock or tested EHT build" ;;
esac

ui_print "- POCO F7 / onyx"
ui_print "- Target: crDroid 13 Android 17 Beta"
ui_print "- Unified 6 GHz + Wi-Fi 7 + 320 MHz SoftAP module"
ui_print "- Includes verified SELinux policy for isolated X1/X2 libraries"

set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/sepolicy.rule" 0 0 0644
set_perm "$MODPATH/system/vendor/bin/hw/hostapd" 0 0 0755
set_perm "$MODPATH/system/vendor/etc/wifi/wcn7750/WCNSS_qcom_cfg.ini" 0 0 0644
set_perm "$MODPATH/system/vendor/overlay/POCOF7CrDroid17Wifi7Overlay.apk" 0 0 0644
set_perm_recursive "$MODPATH/system/vendor/etc/wifi/hostapd_miui_libs" 0 0 0755 0644
