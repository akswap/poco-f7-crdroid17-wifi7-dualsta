#!/system/bin/sh

MODDIR="${0%/*}"
POLICY_LOG="$MODDIR/policy-boot.log"

resetprop -n ro.boot.wificountrycode US
resetprop -n ro.boot.countrycode us
resetprop -n ro.product.countrycode us

# Magisk normally loads sepolicy.rule itself. Apply the same rule live as a
# compatibility fallback for builds where module policy loading is delayed.
if command -v magiskpolicy >/dev/null 2>&1; then
  magiskpolicy --live --apply "$MODDIR/sepolicy.rule" > "$POLICY_LOG" 2>&1
  rc=$?
  echo "policy_apply_rc=$rc uptime=$(cat /proc/uptime)" >> "$POLICY_LOG"
fi
