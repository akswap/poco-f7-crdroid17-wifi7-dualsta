Target: POCO F7 (onyx), crDroidAndroid-17.0-20261002-onyx-v13.0-BETA

Single-module changes:
- WCNSS_qcom_cfg.ini from this exact ROM with BandCapability=7
- scan_mode_6ghz=1
- oem_6g_support_disable=0
- gEnableSelfRecovery remains 1
- boot/framework Wi-Fi country US
- Android 17 Wi-Fi resource overlay enables 802.11be/Wi-Fi 7 SoftAP flags
- Xiaomi EHT hostapd with isolated private X1/X2 libraries and embedded RUNPATH
- SELinux policy permits the hostapd domain to load those isolated libraries

Live verification before packaging v1.2:
- Windows Intel BE200 negotiated protocol 802.11be
- 6 GHz channel 133 / 6615 MHz
- 320 MHz channel width
- 4803 Mbps receive link reported during the verified connection

This module does not include a WLAN .ko and does not replace global vendor libraries.
It is guarded to the exact crDroid 17 service-wifi.jar, stock hostapd and vendor fingerprint.
