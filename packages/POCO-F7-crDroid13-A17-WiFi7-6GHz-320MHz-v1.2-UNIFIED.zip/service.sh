#!/system/bin/sh

MODDIR="${0%/*}"
LOG="$MODDIR/runtime.log"

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

sleep 8

log_msg() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
  size="$(wc -c < "$LOG" 2>/dev/null)"
  if [ -n "$size" ] && [ "$size" -gt 32768 ]; then
    tail -n 100 "$LOG" > "$LOG.tmp" 2>/dev/null
    mv -f "$LOG.tmp" "$LOG" 2>/dev/null
  fi
}

apply_country() {
  result="$(cmd wifi force-country-code enabled US 2>&1)"
  log_msg "force-country-code: $result"
  if command -v iw >/dev/null 2>&1; then
    iw reg set US >/dev/null 2>&1
  fi
}

apply_country

while true; do
  current="$(cmd wifi get-country-code 2>/dev/null)"
  if ! echo "$current" | grep -q 'US'; then
    log_msg "country drift detected: ${current:-unknown}"
    apply_country
  fi

  if command -v iw >/dev/null 2>&1; then
    for iface in $(iw dev 2>/dev/null | awk '$1 == "Interface" {i=$2} $1 == "type" && $2 == "AP" {print i}'); do
      info="$(iw dev "$iface" info 2>/dev/null)"
      freq="$(echo "$info" | awk '$1 == "channel" {gsub(/[()]/, "", $3); print $3; exit}')"
      tx="$(echo "$info" | awk '$1 == "txpower" {print $2; exit}')"
      if [ -n "$freq" ] && [ "$freq" -ge 5925 ] 2>/dev/null && [ "$freq" -le 7125 ] 2>/dev/null && [ -n "$tx" ]; then
        if awk -v value="$tx" 'BEGIN { exit !((value + 0) <= 10) }'; then
          iw dev "$iface" set txpower auto >/dev/null 2>&1
        fi
      fi
    done
  fi
  sleep 30
done
