#!/system/bin/sh

echo "Applying Wi-Fi and SoftAP country code US"
cmd wifi force-country-code enabled US
if command -v iw >/dev/null 2>&1; then
  iw reg set US
fi
echo "Done"
